# cnn-cam
An open python library for researchers and developers to generate GradCAM explanations for the tensorflow CNN models. 

Other popular python ML frameworks will soon be supported by the cnn-cam library
